class Patron {
	String name;
	String mobileNumber;
	Patron (String name, String mobileNumber) {
		this.name = name;
		this.mobileNumber = mobileNumber;
	}
}